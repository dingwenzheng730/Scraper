const express =require('express');
const router = express.Router();

const Post = require('../models/Post')

router.get('/', (req, res) => {
	search_text = req.param('text');
	if (search_text){
        Post.find({ "company": { "$regex": search_text, "$options": "i" } },
            function(err,docs) {
                res.json(docs);
                //res.json("{title: helfdsadfsdfdssdfasfdfslo, id: 1}")

            });
	} else {
		Post.find({}, (err, docs)=>{
		res.json(docs);
	    });
	}
	
});

router.put('/addtag', (req, res) => {
    tag_name = req.param('tag');
    id = req.param('id');
    old_tag = Post.findById(id).tags;
});

module.exports = router;