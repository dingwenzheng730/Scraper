const mongoose = require("mongoose");

const PostSchema = mongoose.Schema({
	title: {
		type: String,
		required: true
	},
	ref: {
		type: String,
		required:false
	},
	location: {
		type: String,
		required: false
	},
	company: {
		type: String,
        required: true
	},
	summary: {
		type: String,
		required: false
	},
	tags: [{
        type: String,
        required: false
    }]
});

module.exports = mongoose.model("Post", PostSchema)