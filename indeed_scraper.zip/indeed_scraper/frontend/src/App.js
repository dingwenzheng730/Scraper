import React, { Component } from 'react';
import './App.css';

class App extends Component {
  constructor(props){
    super(props);
    this.state = {
    	isLoaded: false,
    	items: [],
    }
  }

    componentDidMount() {
  	fetch('/posts?text=IBM')
  	    .then(res =>  res.json())
  	    .then(json => {
  	    	this.setState({
  	    		'isLoaded': true,
  	    		'items': json,
  	    	})
  	    });
    }

    render() {
  	    var isLoaded= this.state.isLoaded;
        var items = this.state.items;
  	    if (!isLoaded) {
          console.log(this.state.items);
  		    return <div> Loading ...</div>;
  	    } else {
            return (
                <div className="App">
                    <ul>
                        {items.map(item => (
                    	    <li key={item.id}>
                    	        <br/>{item.title}
                              <br/>{item.company}
                              <br/>{item.ref}
                              <br/>{item.summary}
                    	    </li>
                        ))}
                    </ul>
                    <input id="searchinput" type="text" />
                    <button onClick='search'>Search</button>
                </div>
            );

  	    }
    }
}

export default App;
