const cheerio = require('cheerio');
const request = require('request');
const express =require('express');
const mongoose = require('mongoose');
const Post = require('./models/Post')

const domain = "https://ca.indeed.com/";
const target = "jobs?q=Software+Developer&start=";

const app = express();

mongoose.connect("mongodb+srv://dingwenzheng730:shasini123@cluster0.c1sme.mongodb.net/indeed_postings?retryWrites=true&w=majority", 
	{ useNewUrlParser: true, useUnifiedTopology: true}, 
	()=>console.log("Connected to DataBase!"));
var connection = mongoose.createConnection('mongodb://localhost:27017/test');


/**
//Used for insert data 
function save_objects() {
	for(i=0;i<50;i++) {
		number = i * 10;
		url = domain + target + number;
		request(url, (error, response, body) =>{
			var $ = cheerio.load(body);

			$('.jobsearch-SerpJobCard').each((index,element)=>
			{
				var title = $('.title', element).text();
				var ref = domain.slice(0,-1) + $('a', $(element).children('.title')).attr('href');
				var location = $('.location', element).text();
				var company = $('.company', element).text();
				var summary = $('.summary', element).text();
				var tags =[];
                
				var obj = {title, ref, location, company, summary, tags};
				var post = new Post(obj);
				post.save();
			})
		})
	}
}*

save_objects(); **/

// ROUTES
const postsRoute = require('./routes/posts');

app.get('/', (req, res) => {
	res.send("hello!");
});

app.use('/posts', postsRoute);


app.listen(8000);

